const {faker} = require('@faker-js/faker');
const {getLists, createList, updateList, deleteList} = require("../../commonMethods/listsMethods");

describe('interaction with lists from clickup: GET, POST, PUT, DELETE', () => {

    it('get all lists', () => {
        getLists('/folder/90122619397/list?archived=false').then((response) => {
            cy.log(response)
            expect(response.status).to.eq(200)
        })
    });

    it('create a new list', () => {
        createList('/folder/90122754485/list').then((response) => {
            expect(response.status).to.eq(200)
        });
    })

    it('get all folderless lists', () => {
        getLists('/space/90121459531/list').then((response) => {
            expect(response.status).to.eq(200)
        })
    });

    it('create a new folderless list', () => {
        createList('/space/90121459531/list').then((response) => {
            expect(response.status).to.eq(200)
        });
    });


    it('get list by id', () => {
        getLists('/list/901205382998').then((response) => {
            expect(response.status).to.eq(200)
        })
    });

    it('update list by id', () => {
        createList('/folder/90122754485/list').then((response) => {
            const listID = response.body.id
            updateList(listID).then((response) => {
                expect(response.status).to.eq(200)
            })
        })
    });

    it('delete list by id', () => {
        createList('/folder/90122754485/list').then((response) => {
            const listID = response.body.id
            deleteList(listID).then((response) => {
                expect(response.status).to.eq(200)
            })
        })
    });

})