import {faker} from "@faker-js/faker";

export const getLists = (url) => {
    return cy.sendRequest('GET', url)
}

export const createList = (url) => {
    const listName = faker.internet.username()
    return cy.sendRequest('POST', url, {
        name: listName,
        content: "New List Content",
        due_date: 1567780450202,
        due_date_time: false,
        priority: 1,
        status: "red"
    })
}

export const updateList = (listID) => {
    const updatedListName = faker.internet.username()
    return cy.sendRequest('PUT', `/list/${listID}`, {
        name: updatedListName,
        content: "Updated List Content",
        due_date: 1567780450202,
        due_date_time: true,
        priority: 2,
        assignee: "none",
        status: "red",
        unset_status: true
    })
}

export const deleteList = (listID) => {
    return cy.sendRequest('DELETE', `/list/${listID}`)
}